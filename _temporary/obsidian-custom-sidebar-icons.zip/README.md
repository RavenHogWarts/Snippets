# Custom Sidebar Icons
自定义固定在侧边栏的文件的icon

# 版本迭代
## v0.2.1
- 彩色svg图标显示支持
## v0.2.0
- 增加svg图标预览
## V0.1.0
- 修改图标基础功能完成